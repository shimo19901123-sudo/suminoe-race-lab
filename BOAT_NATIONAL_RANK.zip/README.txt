BOAT RACE LAB — Nationwide high-odds ranking add-on

1. Open https://github.com/shimo19901123-sudo/suminoe-race-lab/upload/main
2. Upload national_rank.js next to index.html and commit the change.
3. Open index.html on GitHub and click Edit. Immediately BEFORE </body>, add:

<script src="./national_rank.js"></script>

4. Commit the index.html edit. Reload:
https://shimo19901123-sudo.github.io/suminoe-race-lab/

Note: This ZIP is an add-on, not a stand-alone index.html.
It leaves existing daily hit rate, 100-yen payout simulation, and manual entries unchanged.
The model share is not a validated win probability; the reference value is not a verified expected return.
Live data and the published website are not verified.
