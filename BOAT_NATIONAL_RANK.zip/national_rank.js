/* BOAT RACE LAB — nationwide high-odds candidate overlay v1.0
   Existing 1-day hit-rate, 100-yen simulation, manual input and venue details remain intact.
   Load this file AFTER the existing inline script:
   <script src="./national_rank.js"></script>
*/
(() => {
  'use strict';

  const sectionHTML = `
    <div class="section-heading">
      <h2>全国24場・高オッズ候補ランキング <span class="auto-small">参考</span></h2>
      <span class="micro" id="nationCount">0件</span>
    </div>
    <p class="section-desc">会場を分けず全国の開催レースを比較。「1着艇の全国勝率」「独自モデルの3連単参考比率」「取得済みの3連単オッズ」の条件に合う買い目を、1レース1点だけ表示します。</p>
    <div class="nation-controls">
      <label>最低オッズ
        <select id="nationMinOdds" aria-label="全国ランキング最低オッズ">
          <option value="10">10倍以上</option><option value="20" selected>20倍以上</option>
          <option value="30">30倍以上</option><option value="50">50倍以上</option>
          <option value="100">100倍以上</option>
        </select>
      </label>
      <label>1着艇の全国勝率
        <select id="nationMinWin" aria-label="1着艇最低全国勝率">
          <option value="0">指定なし</option><option value="6">6.00以上</option>
          <option value="6.5" selected>6.50以上</option><option value="7">7.00以上</option>
          <option value="7.5">7.50以上</option>
        </select>
      </label>
      <label>3連単の参考比率
        <select id="nationMinShare" aria-label="3連単の参考比率">
          <option value="0">指定なし</option><option value="1">1.0%以上</option>
          <option value="1.5" selected>1.5%以上</option><option value="2">2.0%以上</option>
          <option value="3">3.0%以上</option><option value="5">5.0%以上</option>
        </select>
      </label>
      <label>並び順
        <select id="nationSort" aria-label="全国ランキング並び順">
          <option value="balance" selected>参考期待指標が高い順</option>
          <option value="share">参考比率が高い順</option>
          <option value="odds">オッズが高い順</option>
        </select>
      </label>
    </div>
    <p class="auto-status" id="nationStatus" role="status">全国のレースを集計しています…</p>
    <div id="nationList" class="national-list"></div>
    <p class="disclaimer">参考比率は未検証モデルの相対的な組み合わせ重みで、実際の的中確率ではありません。参考期待指標＝参考比率×集計中オッズ。これも真の期待値・利益の保証ではありません。オッズは締切の約5分前に記録される非公式スナップショットで、最新・確定オッズではありません。投票前に公式で締切、発売状況、欠場、オッズを確認してください。</p>`;

  const styles = `
    .nation-controls{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}
    .nation-controls label{display:flex;flex-direction:column;gap:6px;color:#bad5e8;font-size:12px;font-weight:700}
    .nation-controls select{width:100%;min-width:0;padding:11px 8px;background:#101f33;color:#f0fbff;border:1px solid #47617a;border-radius:10px;font-size:14px}
    .nation-rank{font-size:12px;font-weight:900;color:#ffcf86}
    .nation-pick{display:block;font-size:20px;line-height:1.5;font-weight:900;color:#78ebd3}
    .nation-metrics{display:flex;flex-wrap:wrap;gap:6px 13px;font-size:12px;margin:7px 0;color:#c1d8e8}
    .nation-metrics strong{color:#f0f9ff}
    .nation-metrics .metric-highlight{color:#ffdda2}
    .national-card .nation-right{color:#ffdda2;font-size:12px;text-align:right}
    .national-card .nation-right strong{display:block;font-size:20px;color:#81eed9}
    @media(max-width:420px){.nation-controls{gap:8px}.nation-controls select{padding:10px 6px;font-size:13px}.national-card .nation-right{text-align:left}}
  `;

  function compare(a, b, mode) {
    if (mode === 'share') return b.modelShare-a.modelShare || b.reference-a.reference;
    if (mode === 'odds') return b.odd-a.odd || b.modelShare-a.modelShare;
    return b.reference-a.reference || b.modelShare-a.modelShare;
  }

  function calculateCandidates({races, getData, getOdds, rank, isComplete,
      parseClose, today, now, minOdds, minWin, minShare, sortBy}) {
    const all = [];
    let eligible = 0, oddsAvailable = 0;
    for (const {v,n} of races) {
      if (!Number.isInteger(v) || v < 1 || v > 24 || !Number.isInteger(n) || n < 1 || n > 12) continue;
      const src = getData(v,n);
      if (!src?.players || !isComplete(src.players) || src.triple) continue;
      const closedAt = parseClose(src);
      if (today && (!Number.isFinite(closedAt) || closedAt <= now)) continue;
      eligible++;
      const snap = getOdds(v,n);
      if (!snap?.odds || Object.keys(snap.odds).length === 0) continue;
      oddsAvailable++;
      const model = rank(src.players);
      if (!model?.combos?.length) continue;
      const choices = [];
      for (const modelCombo of model.combos) {
        const combo = modelCombo.lanes.join('-');
        const odd = Number(snap.odds[combo]);
        const modelShare = Number(modelCombo.weight)*100;
        const firstWin = Number(src.players[modelCombo.lanes[0]-1]?.win);
        if (!Number.isFinite(odd) || odd < minOdds ||
            !Number.isFinite(modelShare) || modelShare < minShare ||
            !Number.isFinite(firstWin) || firstWin < minWin) continue;
        choices.push({combo,odd,modelShare,firstWin,reference:odd*modelShare/100});
      }
      if (!choices.length) continue;
      choices.sort((a,b)=>compare(a,b,sortBy));
      all.push({...choices[0],v,n,closedAt,closeTime:snap.closeTime||'',
        capturedAt:snap.capturedAt||''});
    }
    all.sort((a,b)=>compare(a,b,sortBy) || a.closedAt-b.closedAt || a.v-b.v || a.n-b.n);
    return {all, eligible, oddsAvailable};
  }

  function renderNationalRank() {
    const list = document.getElementById('nationList');
    const status = document.getElementById('nationStatus');
    if (!list || !status) return;
    // Existing app globals are read, never overwritten.
    const selectedDate = date;
    const source = autoCache.days[selectedDate]?.venues||{};
    const seen = new Map();
    for (const [vs, rr] of Object.entries(source))
      for (const ns of Object.keys(rr||{})) seen.set(`${Number(vs)}_${Number(ns)}`,{v:Number(vs),n:Number(ns)});
    for (const k of Object.keys(state.races)) {
      const p=parseKey(k);
      if (p && p.d===selectedDate) seen.set(`${p.v}_${p.n}`,{v:p.v,n:p.n});
    }
    for (const k of Object.keys(SEED)) {
      const p=parseKey(k);
      if (p && p.d===selectedDate) seen.set(`${p.v}_${p.n}`,{v:p.v,n:p.n});
    }
    const todayText=inJST(), isToday=selectedDate===todayText;
    const filtered=calculateCandidates({
      races:[...seen.values()],
      getData:(v,n)=>dataFor(selectedDate,n,v),
      getOdds:(v,n)=>autoOddsFor(selectedDate,v,n),
      rank:rankModel,
      isComplete:complete,
      parseClose:publishedCloseMs,
      today:isToday,
      now:Date.now(),
      minOdds:Number(document.getElementById('nationMinOdds').value),
      minWin:Number(document.getElementById('nationMinWin').value),
      minShare:Number(document.getElementById('nationMinShare').value),
      sortBy:document.getElementById('nationSort').value
    });
    const all=filtered.all;
    document.getElementById('nationCount').textContent=`${all.length}件`;
    status.textContent=`全国24場から比較：対象${filtered.eligible}レース ／ オッズ確認${filtered.oddsAvailable}レース ／ 条件一致${all.length}レース（各1点）`;

    if (selectedDate<todayText) {
      list.innerHTML='<p class="section-desc">過去日は購入候補を表示しません。的中率と収支は「結果」で確認してください。</p>';
      return;
    }
    if (!all.length) {
      list.innerHTML=filtered.oddsAvailable
        ?'<p class="section-desc">現在の条件をすべて満たす買い目はありません。絞り込み条件を調整すると候補が見つかることがあります。</p>'
        :'<p class="section-desc">対象レースの3連単オッズはまだ取得できていません。通常は締切約5分前の配信後に、自動で再確認します。</p>';
      return;
    }
    list.innerHTML=all.slice(0,24).map((x,i)=>{
      const time=Date.parse(x.capturedAt);
      const captured=Number.isFinite(time)?new Intl.DateTimeFormat('ja-JP',
        {timeZone:'Asia/Tokyo',hour:'2-digit',minute:'2-digit'}).format(new Date(time)):'不明';
      const closed=Number.isFinite(x.closedAt)?new Intl.DateTimeFormat('ja-JP',
        {timeZone:'Asia/Tokyo',hour:'2-digit',minute:'2-digit'}).format(new Date(x.closedAt)):
        (x.closeTime||'不明');
      return `<button type="button" class="national-card" data-national-v="${x.v}" data-national-n="${x.n}">
        <span>
          <span class="nation-rank">全国候補 ${i+1}位</span>
          <b style="display:block;margin:4px 0">${escapeHTML(venueName(x.v))} ${x.n}R ／ 3連単</b>
          <span class="nation-pick">${escapeHTML(x.combo)}</span>
          <span class="nation-metrics"><span>1着艇 全国勝率 <strong>${x.firstWin.toFixed(2)}</strong></span>
            <span>参考比率 <strong>${x.modelShare.toFixed(2)}%</strong></span>
            <span class="metric-highlight">参考期待指標 ${x.reference.toFixed(2)}</span></span>
          <small>オッズ記録 ${captured} ／ 締切 ${escapeHTML(closed)}（公式で再確認）</small>
        </span>
        <span class="nation-right">取得オッズ<strong>${x.odd.toFixed(1)}倍</strong><small>詳しく見る</small></span>
      </button>`;
    }).join('');
    list.querySelectorAll('[data-national-v]').forEach(button=>{
      button.addEventListener('click',()=>{
        venue=Number(button.dataset.nationalV);
        race=Number(button.dataset.nationalN);
        setView('home');
        renderAll();
      });
    });
  }

  function installNationalRank() {
    const section=document.querySelector('section.nationwide');
    if (!section) return;
    const style=document.createElement('style');
    style.textContent=styles;
    document.head.appendChild(style);
    section.innerHTML=sectionHTML;
    const selection=document.querySelector('section.selection');
    if (selection && section.parentElement===selection.parentElement) selection.before(section);
    ['nationMinOdds','nationMinWin','nationMinShare','nationSort'].forEach(id=>{
      document.getElementById(id).addEventListener('change',renderNationalRank);
    });
    renderNationalRank();
  }

  // Existing fetchAutoData/fetchAutoOdds/renderAll call renderNation.
  // Reassigning the global function also keeps their auto-refresh behavior.
  window.renderNation=renderNationalRank;
  if (document.readyState==='loading')
    document.addEventListener('DOMContentLoaded',installNationalRank);
  else installNationalRank();

  // Small test hook for isolated deterministic tests; no network or betting action.
  window.__nationalRankingTest={calculateCandidates};
})();
